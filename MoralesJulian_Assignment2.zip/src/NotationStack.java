import java.util.ArrayList;

public class NotationStack<T> implements StackInterface<T> {

    private ArrayList<T> stack;
    private ArrayList<String> stack2;

    private int size;
    

    public NotationStack() {
        stack = new ArrayList<>();
        size = 1000;
    }

    public NotationStack(int capacity) {
        stack = new ArrayList<>(capacity);
        this.size = capacity;
    }

	public NotationStack(ArrayList<String> fill) {
		stack2 = new ArrayList<>(fill);
		fill.addAll(stack2);
	}

	@Override
    public boolean isEmpty() {
        return stack.isEmpty();
    }

    @Override
    public boolean isFull() {
        return stack.size() == size;
    }

    @Override
    public T pop() throws StackUnderflowException {
        if (!isEmpty()) {
            T element = stack.get(size() - 1);
            stack.remove(size() - 1);
            return element;
        } else { 
            throw new StackUnderflowException();
        }
    }

    //@Override
    public T peek() throws StackUnderflowException {
        if (!isEmpty()) {
            return stack.get(size() - 1);
        } else {
            throw new StackUnderflowException();
        }
    }

    @Override
    public int size() {
        return stack.size();
    }

    @Override
    public boolean push(T e) throws StackOverflowException {
        if (!isFull()) {
            return stack.add(e);
        } else {
            throw new StackOverflowException();
        }
    }

    @Override
    public String toString() {
        String strStack = "";
        for (T e : stack) {
            strStack += e;
        }
        return strStack;
    }
    
    @Override
    public String toString(String delimiter) {
        String strStack = "";
        for (T e : stack) {
            strStack += e + delimiter;
        }
        return strStack.substring(0, strStack.length() - 1);
    }

    //@Override
    public void fill(ArrayList<T> list) throws StackOverflowException {
        for (T element : list) {
            push(element);
        }
    }

	@Override
	public T top() throws StackUnderflowException{
		if (stack.size() == 0) {
			throw new StackUnderflowException();
		}
		return stack.get(stack.size()-1);
	}
    
}

