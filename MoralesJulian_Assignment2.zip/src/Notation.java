import java.util.HashMap;

public class Notation {
    
    public static String convertInfixToPostfix(String infix) {
        
    	NotationStack<String> opStack = new NotationStack<>(infix.length());
        opStack.push("");
        
        NotationQueue<String> postfixSol = new NotationQueue<>(infix.length());
        postfixSol.enqueue("");
        
        HashMap<String, Integer> precedence = new HashMap<>();
        precedence.put("-", 1);
        precedence.put("+", 2);
        precedence.put("/", 3);
        precedence.put("*", 4);
            
        boolean isTopOp = false, higherPrecedence;
        
        for (char c : infix.toCharArray()) {
                        
            String nextChar = String.valueOf(c);
            
            for (String op : precedence.keySet()) {
                isTopOp = opStack.peek().equals(op);
                if (isTopOp) {
                    break;
                }
            }

            try {
                higherPrecedence = precedence.get(opStack.peek()) 
                        >= precedence.get(nextChar);
            } catch (NullPointerException e) {
                higherPrecedence = false;
            }
            
            if (Character.isDigit(c)) {
                postfixSol.enqueue(nextChar);
            } else if (c == '(') {
                opStack.push(nextChar);
            } else if (c == '-' || c == '+' || c == '/' || c == '*') {
                if (opStack.peek().equals("-") || 
                        opStack.peek().equals("+") ||
                        opStack.peek().equals("/") ||
                        opStack.peek().equals("*")) {
                    throw new InvalidNotationFormatException();
                }
                if (isTopOp && higherPrecedence) {
                    postfixSol.enqueue(opStack.pop());
                }
                opStack.push(nextChar);
            } else if (c == ')') {

                try {
                    while (!opStack.peek().equals("(")) {
                        postfixSol.enqueue(opStack.pop());
                    }
                } catch (StackUnderflowException e) {
                    throw new InvalidNotationFormatException();
                }
                opStack.pop();
            }                        
        } 
        
        while (!opStack.isEmpty() && (isTopOp)) {
            postfixSol.enqueue(opStack.pop());
        }
        
        for (char c : postfixSol.toString().toCharArray()) {
            if (c == '(') {
                throw new InvalidNotationFormatException();
            }
        }
                
        return postfixSol.toString();
    }
    
    public static String convertPostfixToInfix(String postfix) {
        NotationStack<String> infixSol = new NotationStack<>(postfix.length());
        infixSol.push("");
        
        for (char c : postfix.toCharArray()) {
            
            String nextChar = String.valueOf(c);
            
            if (Character.isDigit(c)) {
                infixSol.push(nextChar);
            } else if (c == '-' || c == '+' || c == '/' || c == '*') {
                if (infixSol.size() < 3) {
                    throw new InvalidNotationFormatException();
                }
                String first = infixSol.pop(), second = infixSol.pop();
                String result = '(' + second + c + first + ')';
                infixSol.push(result);
            }
        }
        
        if (infixSol.size() > 2) {
            throw new InvalidNotationFormatException();
        }
        
        return infixSol.toString();
    }
    
    public static double evaluateInfixExpression(String infixE) {
        
        return evaluatePostfixExpression(convertInfixToPostfix(infixE));
    }
    
    public static double evaluatePostfixExpression(String postfixE) {
        NotationStack<Double> valStack = new NotationStack<>(postfixE.length());
        valStack.push(Double.NaN);
        
        for (char c : postfixE.toCharArray()) {
                        
            if (Character.isDigit(c)) {
                valStack.push(Double.parseDouble(String.valueOf(c)));
            } else if (c == '-' || c == '+' || c == '/' || c == '*') {
                if (valStack.size() < 3) {
                    throw new InvalidNotationFormatException();
                }
                double first = valStack.pop(), second = valStack.pop();
                double result = (c == '-') ? second - first : 
                        (c == '+') ? second + first : 
                        (c == '/') ? second / first :
                        (c == '*') ? second * first : 0;
                valStack.push(result);
            } 
            
        }
        
        if (valStack.size() > 2) {
            throw new InvalidNotationFormatException();
        }
        
        return valStack.peek();
    }
}


