import java.util.ArrayList;

public class NotationQueue<T> implements QueueInterface<T>{
    
    private ArrayList<T> queue;
    private ArrayList<String> stack2;
  
    private int size;
    
    public ArrayList<String> a;
    
    public NotationQueue() {
        queue = new ArrayList<>();
        size = 1000;
    }

    public NotationQueue(int capacity) {
        queue = new ArrayList<>(capacity);
        this.size = capacity;
    }

	public NotationQueue(ArrayList<String> fill) {
		stack2 = new ArrayList<>(fill);
		fill.addAll(stack2);
	}

	@Override
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    @Override
    public boolean isFull() {
        return queue.size() == size;
    }

    @Override
    public T dequeue() throws QueueUnderflowException {
        if (!isEmpty()) {
            T element = queue.get(0);
            queue.remove(0);
            return element;
        } else { 
            throw new QueueUnderflowException();
        }
    }

    @Override
    public int size() {
        return queue.size();
    }

    @Override
    public boolean enqueue(T e) throws QueueOverflowException {
        if (!isFull()) {
            return queue.add(e);
        } else {
            throw new QueueOverflowException();
        }
    }

    @Override
    public String toString() {
        String strQueue = "";
        for (T e : queue) {
            strQueue += e;
        }
        return strQueue;
    }
    
    @Override
    public String toString(String delimiter) {
        String strQueue = "";
        for (T e : queue) {
            strQueue += e + delimiter;
        }
        return strQueue.substring(0, strQueue.length() - 1);
    }

    @Override
    public void fill(ArrayList<T> list) {
        for (T element : list) {
            enqueue(element);
        }
    }
    
}