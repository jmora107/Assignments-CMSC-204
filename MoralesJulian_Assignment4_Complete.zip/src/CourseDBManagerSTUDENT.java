import static org.junit.Assert.*;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CourseDBManagerSTUDENT
{
	CourseDBManagerInterface manager = new CourseDBManager();

	@Before
	public void setUp() throws Exception
	{
		manager = new CourseDBManager();
	}

	@After
	public void tearDown() throws Exception
	{
		manager = null;
	}

	@Test
	public void testAdd()
	{
		try {
			manager.add("CMSC101",28769,4,"SC110","John Smith");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}

	@Test
	public void testShowAll()
	{
		manager.add("CMSC101",28769,4,"SC110","John Smith");
		manager.add("CMSC101",28321,4,"SC110","Alex Albon");
		manager.add("CMSC101",38766,4,"SC110","George Russell");
		ArrayList<String> list = manager.showAll();

		assertEquals(list.get(0),"\nCourse:CMSC101 CRN:28321 Credits:4 Instructor:Alex Albon Room:SC110");
		assertEquals(list.get(1),"\nCourse:CMSC101 CRN:28769 Credits:4 Instructor:John Smith Room:SC110");
		assertEquals(list.get(2),"\nCourse:CMSC101 CRN:38766 Credits:4 Instructor:George Russell Room:SC110");
	}

	@Test
	public void testReadFile()
	{
		try {
			File inputFile = new File("Course.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("CMSC101 28321 4 SC110 Alex Albon");
			inFile.print("CMSC101 28769 4 SC110 John Smith");

			inFile.close();
			manager.readFile(inputFile);
		} catch (Exception e) {
			fail("Should not have thrown an exception");
		}
	}



}
