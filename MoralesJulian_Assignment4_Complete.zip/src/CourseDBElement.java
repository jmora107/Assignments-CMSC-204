import java.util.ArrayList;

public class CourseDBElement implements Comparable
{
	String roomNumber, instructorName, hashcode, courseID;
	int CRN, numberOfCredits;
	
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public int getCRN() {
		return CRN;
	}
	public void setCRN(int crn) {
		this.CRN = crn;
	}
	public int getNumCredits() {
		return numberOfCredits;
	}
	public void setNumCredits(int numCredits) {
		this.numberOfCredits = numCredits;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNum(String roomNum) {
		this.roomNumber = roomNum;
	}
	public String getInstructorName() {
		return instructorName;
	}
	public void setInstructorName(String instructorName) {
		this.instructorName = instructorName;
	}
	public CourseDBElement()
	{
		courseID = null;
		CRN = 0;
		numberOfCredits = 0;
		roomNumber = null;
		instructorName = null;
		this.hashcode=hashcode();
	}

	public CourseDBElement(String courseID,int CRN,int numCredits,String roomNum,String instructorName)
	{
		this.courseID = courseID;
		this.CRN = CRN;
		this.numberOfCredits = numCredits;
		this.roomNumber = roomNum;
		this.instructorName = instructorName;
		this.hashcode=hashcode();
	}

	public String toString()
	{
		String string = ("Course:"+courseID +" CRN:"+CRN +" Credits:"+numberOfCredits +" Instructor:"+instructorName
					+" Room:"+roomNumber);
		return string;
	}



	public String hashcode()
	{
		return ""+((""+CRN).hashCode());
	}

	@Override
	public int compareTo(CourseDBElement element)
	{
		if(CRN < element.CRN)
			
			return -1;
		else if(CRN > element.CRN)
			
			return 1;
		else
			
			return 0;
	}

}
