import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface
{
	CourseDBStructure CDS = new CourseDBStructure(20);
	CourseDBElement CDE = new CourseDBElement();

	@Override
	public void add(String ID, int CRN, int credits, String roomNumber, String instructor)
	{
		CourseDBElement CDE = new CourseDBElement(ID, CRN, credits, roomNumber, instructor);
		CDS.add(CDE);
	}

	@Override
	public CourseDBElement get(int CRN)
	{
		try {
			return CDS.get(CRN);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void readFile(File input) throws FileNotFoundException
	{
		String file = "C:\\Users\\Julian Morales\\Documents\\text file asgnmt 4\\courses(1).txt";
		Scanner scanner = new Scanner(new FileInputStream(file));
		while (scanner.hasNextLine())
		{
			System.out.println(scanner.nextLine());
		}
		scanner.close(); 
	}

	@Override
	public ArrayList<String> showAll()
	{
		return CDS.showAll();
	}

	public static void main(String args[]) throws IOException
	{
		String file = "C:\\Users\\Julian Morales\\Documents\\text file asgnmt 4\\courses(1).txt";

	}



}
