
public class TreeNode<T> {

    protected T data;
    protected TreeNode<T> leftC;
    protected TreeNode<T> rightC;

    public TreeNode(T dataNode) {
        data = dataNode;
        leftC = null;
        rightC = null;
    }

    public TreeNode(TreeNode<T> node) {
    	data = node.data;
    	leftC = new TreeNode<>(node.leftC);
        rightC = new TreeNode<>(node.rightC);
    }

    public T getData() {
        return data;
    }
}