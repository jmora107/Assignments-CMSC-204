import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MorseCodeConverter 
{

    private static MorseCodeTree tree = new MorseCodeTree();

    public static String convertToEnglish(String textInMorse) 
    {
        String textInEnglish = "";
        String[] wordsInMorse = textInMorse.split("/");
        String[][] sets = new String[wordsInMorse.length][];
        
        for (int i = 0; i < sets.length; i++) 
        {
            sets[i] = wordsInMorse[i].split(" ");
        }
                
        for (int i = 0; i < sets.length; i++) 
        {
            for (int j = 0; j < sets[i].length; j++) 
            {
                sets[i][j] = tree.fetch(sets[i][j]);
                textInEnglish += sets[i][j];
            }
            
            textInEnglish += (i == sets.length - 1) ? "" : " ";
        }
        
        return textInEnglish;
    }

    public static String convertToEnglish(File file) 
    		
    		throws FileNotFoundException 
    {
    	
        Scanner read = new Scanner(file);
        String text = "";
        while (read.hasNextLine()) 
        {
            text += read.nextLine();
        }
        
        return convertToEnglish(text);
    }

    public static String printTree() 
    {
        String treeAsString = "";
        for (String e : tree.toArrayList()) 
        {
            treeAsString += e + " ";
        }
        return treeAsString;
    }

}