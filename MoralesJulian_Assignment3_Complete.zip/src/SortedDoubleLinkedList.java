import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
   
    protected Comparator<T> comparator = null;
        
    public SortedDoubleLinkedList(Comparator<T> comparator) {
       this.comparator = comparator;
    }
    
    public SortedDoubleLinkedList<T> add(T data) {
        Node newNode = new Node(data);
        
        if (size == 0) {
        	
            first = last = newNode;
        } else if (comparator.compare(first.data, data) > 0) {
        	
            first.previous = newNode;
            newNode.next = first;
            first = newNode;
        } else if (comparator.compare(last.data, data) < 0) {
        	
            last.next = newNode;
            newNode.previous = last;
            last = newNode;
        } else {
        	
            Node search = first;
            while (search != null) {
            	
                if (comparator.compare(search.data, data) <= 0) {
                	
                    Node before = search;
                    Node after = search.next;
                    after.previous = before.next = newNode;
                    newNode.next = after;
                    newNode.previous = before;   
                }
                search = search.next;
            }
        }
        
        size++;
        return this;
    }
      
    @Override
    public BasicDoubleLinkedList<T> addToEnd(T data) {
        throw new UnsupportedOperationException("Invalid operation for sorted list"); 
    }
    
    @Override
    public BasicDoubleLinkedList<T> addToFront(T data) {
        throw new UnsupportedOperationException("Invalid operation for sorted list");
    }

    @Override
    public ListIterator<T> iterator() throws UnsupportedOperationException, NoSuchElementException {
        return super.iterator();
    }

    @Override
    public SortedDoubleLinkedList<T> remove(T data, Comparator<T> comparator) {
        super.remove(data, comparator);
        return this;
    }
    
}