import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T> {

    protected int size = 0;
    protected Node first;
    protected Node last;

    public BasicDoubleLinkedList() {
        first = last = null;
    }
    
    public int getSize() {
        return size;
    }

    public BasicDoubleLinkedList<T> addToEnd(T data) {
        if (last == null) {
        	
            last = new Node(data);
            first = last;
        } else {
        	
            Node newNode = new Node(data);
            last.next = newNode;
            newNode.previous = last;
            last = newNode;
        }
        size++;
        return this;
    }

    public BasicDoubleLinkedList<T> addToFront(T data) {
    	
        if (first == null) {
            first = new Node(data);
            last = first;
        } else {
        	
            Node newNode = new Node(data);
            first.previous = newNode;
            newNode.next = first;
            first = newNode;
        }
        size++;
        return this;
    }

    public T getFirst() {
    	
        return first.data;
    }

    public T getLast() {
    	
        return last.data;

    }

    @Override
    public ListIterator<T> iterator() throws UnsupportedOperationException, NoSuchElementException {
    	
        MyListIterator iterator = new MyListIterator();
        return iterator;
    }

    public BasicDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator) {
    	
        Node node = first;
        while(node != null) {
            if (comparator.compare(node.data, targetData) == 0) {
            	
                if (node == first) {
                    if (first.next != null) {
                    	
                        first = first.next;
                        first.previous = null;
                    } else {
                    	
                        first = last = null;
                    }
                } else if (node == last) {
                	
                    if (last.previous != null) {
                    	
                        last = last.previous;
                        last.next = null;
                    } else {
                    	
                        first = last = null;
                    }
                } else {
                	
                    node.previous.next = node.next;
                    node.next.previous = node.previous;
                }
                break;
            }
            node = node.next;
        }
        size--;
        return this;
    }

    public T retrieveFirstElement() {
    	
        if (first != null) {
        	
            Node firstElement = first;
            if (first.next != null) {
            	
                first = first.next;
                first.previous = null;
            } else {
            	
                first = last = null;
            }
            return firstElement.data;
        } else {
        	
            return null;
        }
        
    }

    public T retrieveLastElement() {
    	
        if (last != null) {
        	
            Node lastElement = last;
            if (last.previous != null) {
            	
                last = last.previous;
                last.next = null;
            } else {
            	
                first = last = null;
            }
            return lastElement.data;
        } else {
        	
            return null;
        }
    }

    public ArrayList<T> toArrayList() {
    	
        ArrayList<T> list = new ArrayList<>();
        Node head = first;
        while(head != null) {
        	
            list.add(head.data);
            head = head.next;
        }
        return list;      
    }

    protected class Node {

        protected T data;

        protected Node next;

        protected Node previous;

        Node(T element) {
        	
            this.data = element;
            this.next = null;
            this.previous = null;
        }

        Node(Node previous, T element, Node next) {
        	
            this.data = element;
            this.next = next;
            this.previous = previous;
        }
    }
    
    protected class MyListIterator implements ListIterator<T> {

        Node pointer;

        public MyListIterator() {
        	
            pointer = new Node(null, null, first);
        }

        @Override
        public boolean hasNext() {
        	
            return pointer.next != null;
        }

        @Override
        public T next() {
            
            if (!hasNext()) {
            	
                throw new NoSuchElementException("There is not a next element");
            } else {
            	
                pointer.previous = pointer.next;
                pointer.next = pointer.previous.next;
                return pointer.previous.data;
            }            
            
        }

        @Override
        public boolean hasPrevious() {
        	
            return pointer.previous != null;
        }

        @Override
        public T previous() {
            
            if (!hasPrevious()) {
            	
                throw new NoSuchElementException("There is not a previous element");
            } else {
            	
                pointer.next = pointer.previous;
                pointer.previous = pointer.next.previous;
                return pointer.next.data;            
            }
        }

        @Override
        public int nextIndex() {
        	
            throw new UnsupportedOperationException("Not supported"); 
        }

        @Override
        public int previousIndex() {
        	
            throw new UnsupportedOperationException("Not supported"); 
        }

        @Override
        public void remove() {
        	
            throw new UnsupportedOperationException("Not supported"); 
        }

        @Override
        public void set(T e) {
        	
            throw new UnsupportedOperationException("Not supported"); 
        }

        @Override
        public void add(T e) {
        	
            throw new UnsupportedOperationException("Not supported"); 
        }
        
    }
}